# Architecture

## Existing defuss instrumentation

The reviewed [defuss-open-telemetry source](https://github.com/kyr0/defuss/blob/4ddb290567db95aa97eb1594d99f7b2afa6c2b8a/packages/open-telemetry/src/index.ts) is version 0.1.2. Its sink lazily creates instruments and adapts a real OpenTelemetry meter to the existing defuss interface. Counter and histogram calls retain their attributes. The bridge stores one gauge value and one attribute set per metric name. Updating a second labeled queue replaces the first. Its in-memory meter appends raw measurements for test inspection.

The service implements the upstream TelemetrySink contract and creates all three instruments on its SDK meter. A shared registry applies the same label schema and series budget to dynamic writes and fixed-label handles. The synchronous gauge keeps a value for each admitted series.

A per-instrument map retains admitted label sets for the instance lifetime. Fixing admission across collections bounds cumulative growth when each interval sees new labels. Each excess sample goes directly to the SDK with its overflow attribute. Both readers have room for all admitted series, the explicit overflow series and the SDK's reserved slot. The SDK aggregates counters and histograms. An async observer has a per-snapshot point limit because it can withdraw earlier series. Both paths validate label types before exposing samples.

## Data flow

```mermaid
flowchart TD
    Probes["Health endpoints"] --> Checks["Async checks"]
    Observers["Async observers"] --> Snapshot["Current gauge samples"]
    Checks --> Snapshot
    Sink["Sink or bound handle"] --> Admission["Series admission"]
    Admission --> SDK["SDK instruments"]
    Snapshot --> Pull["Prometheus reader"]
    Snapshot --> Push["OTLP reader"]
    SDK --> Pull
    SDK --> Push
    Pull --> HTTP["GET /metrics"]
    Push --> Receiver["Collector HTTP receiver"]
```

Each instance owns a meter provider and readers. Importing the package registers no global provider. Creating an instance opens no listener. A distinct resource instance ID defaults to a random UUID. Pass `instanceId` to supply an operator-managed identity. The application owns its server and process signals.

Callback results feed a shared MetricProducer. The SDK's cumulative observable gauge can retain a previous series when the callback emits nothing. Building the gauge points from each snapshot lets vanished or failed sources disappear immediately from both readers. The SDK owns counter and histogram aggregation, resource serialization and the exporter protocol. The additional producer supplies only measurement data. The SDK's Prometheus serializer handles escaping, type metadata and histograms.

## Failure boundaries

Dependent services belong in readiness. A remote database outage then removes the instance from traffic while the liveness probe continues to succeed. An explicit liveness failure also fails readiness. Metrics export is independent of the serving decision. A failing observer exports its success flag alongside the remaining valid metrics. A failing Collector leaves the service's health decision to its registered checks.

Check and observer callbacks each have a single in-flight slot and cooperative cancellation. Timeout resolves the waiting requests. The slot remains occupied until the underlying promise settles. The optional successful-check cache uses a monotonic deadline from completion. Aborted work cannot fill the cache. Each registration owns its deadline. Draining overrides a cached result and skips readiness callbacks. Public metrics calls share a scrape while it is in flight. Built-in RSS is process memory. Host or container metrics require their own source.

A service publishes its state on its existing listener. Read access to the health and metrics routes follows the host application's routing and access controls. The Collector runs as a separate process and owns the OTLP receiver, including validation and protocol responses. The example binds its receiver to loopback. Use Collector exporter configuration to select a storage backend.

## Protocol and project references

- [OTLP/HTTP metrics request and response](https://opentelemetry.io/docs/specs/otlp/#otlphttp-request)
- [Prometheus exposition format](https://prometheus.io/docs/instrumenting/exposition_formats/)
- [Kubernetes container probes](https://kubernetes.io/docs/concepts/workloads/pods/probes/)
- [Verified Agentic Engineering revision used for this release](https://github.com/kyr0/defuss-vae/tree/dc0f6b5ea4973b2f3224a589d38c19386126e09d)
