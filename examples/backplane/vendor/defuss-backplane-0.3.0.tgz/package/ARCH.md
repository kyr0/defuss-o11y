# Architecture

The daemon binds a single IPv4 socket to 127.0.0.1. Node.js and Bun run the same ESM build and use the same disk layout. A local application owns its public HTTP API and its end-user access decisions.

| Boundary | Responsibility |
| --- | --- |
| Server | Validates Host, Origin and the bot credential before dispatch, including schema and tool discovery. Caps request bodies at 1 MiB. |
| RPC | defuss-rpc registers the cache and database functions and returns DSON results. The backend client authenticates its own discovery fetch because defuss-rpc 3.0.0 omits custom headers on that request. |
| MCP | defuss-mcp publishes named JSON schemas and validates the arguments. The adapter maps named fields into the RPC call order and passes each call to the same in-process dispatcher. A document can have arbitrary fields, so the adapter uses the registry's JSON schema API. |
| Engines | defuss-dbsonl 0.9.0 stores cache entries. defuss-db 3.1.0 stores documents in named collections. Each adapter owns its handles. |

The release bundles code from the pinned defuss-db package and its search libraries. The database opens through its public `openDatabase` API with a native file backend. This keeps its storage format and leaves model runtimes out of the consumer installation.

## Storage and concurrency

A logical identifier becomes a lowercase hexadecimal representation of its UTF-8 bytes with an alphabetic prefix. This maps distinct identifiers to distinct filesystem components, even on case-insensitive volumes. The app directory contains its tenant directories. Within each tenant, each cache bucket has a KV store, and DB buckets are named collections. Short names share one database per tenant. When an encoded name exceeds the engine's 64-character collection limit, its remaining digits select a database subdirectory so long names with a common prefix stay distinct. Identical names in different services select different storage.

Each engine pool holds up to 32 handles. A lease keeps its handle open until the operation finishes. Cold opens serialize within the pool to coalesce concurrent requests for the same store. On reaching capacity, a cold open evicts the least recently used idle handle. If all handles are busy, the caller receives an error and may retry that operation.

Cache TTL is an absolute expiry on the daemon clock. A read reports an expired entry as a miss. Expired entries stay on disk until overwritten or explicitly deleted. A cold read checks the shard directory under the pool admission queue. Only a confirmed empty or missing directory qualifies as absent. Existing stores open with creation disabled so an I/O failure propagates. Each write uses its engine's commit protocol. Operations across engines commit independently.

## Revisions

A cache write stores a random token with the value. A conditional change reads the entry, compares its logical revision including TTL, and stages its mutation inside one DBSONL transaction. A v0.1 cache entry derives its first token from its address and persisted entry revision.

In each database partition the user collection starts with `x` and its companion revision collection starts with `v`. The document and token share a native database transaction. A versioned read uses one snapshot for both collections. A legacy document derives a scoped initial token from its typed primary key and the database identity. Reads need no migration write. Successful inserts and updates assign a fresh token, including updates that restore earlier content. Deletes remove both records. Internal metadata stays out of user documents, projections and application bucket names. Revision guarantees cover writes through this daemon. Older daemons and native writers do not maintain the companion collection.

Each network call owns its fault context. The adapters preserve engine error codes before defuss-rpc or defuss-mcp reduces an exception to a message. Successful calls use the protocol's original response. A schema rejection retains its MCP field corrections.

## Security and operations

The daemon requires a bearer key for every network request. It accepts Host values for 127.0.0.1 or localhost at its configured port and rejects any request carrying Origin. The backend client uses a literal loopback URL and rejects redirects. Local processes sharing a bot key share access to all app shards. A backend derives tenant selection from its own authenticated request. Containers need a common network namespace to use this listener.

The service creates data directories with owner-only mode on POSIX. Run it under an account that owns its data root and credentials. Cache entries and documents persist on disk and may contain personal data supplied by the application. The application operator controls retention and backups. On shutdown the listener drains active HTTP work before the engine pools close.

The packed-consumer test installs the tarball into a temporary application and exercises all ten tools. It uses the official MCP client, curl and the typed client. It starts from a fixture written by the v0.1.0 release tarball (SHA-256 fec0fccbbb34e0933578cb9094ddecb994117ccbb4935bf9ff6d1f97928f09d8). Each of six consumer phases upgrades one legacy cache entry and document. Restarts on the same files check revision continuity across runtimes. Concurrent RPC and MCP writes using the same token verify one winning mutation per item.

## Scheduler ownership

When enabled, the daemon opens one defuss-scheduler authority before listening and closes it after draining HTTP work. All buckets share the private scheduler store with full scope in record keys. An exclusive file lock rejects a second daemon targeting the same directory. The remote worker endpoint belongs to the application, where authenticated identities select their scope and allowed handlers. The existing loopback listener retains its original trust model.
